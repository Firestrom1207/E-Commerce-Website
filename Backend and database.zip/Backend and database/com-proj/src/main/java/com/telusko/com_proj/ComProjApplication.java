
package com.telusko.com_proj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComProjApplication.class, args);
	}

}
