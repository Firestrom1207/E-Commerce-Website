package com.telusko.com_proj.model;

import java.util.Arrays;
import java.util.Date;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;


@Entity
@Component
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name;
	private String description;
	private int price;
	private String category;
	private String brand;
	private boolean productAvailable;
	private Date releaseDate;
	private int stockQuantity;
	private String imageName;
	private String imageType;
	@Lob
	private byte[] imageData;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDes() {
		return description;
	}
	public void setDes(String description) {
		this.description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public boolean isAvaliablity() {
		return productAvailable;
	}
	public void setAvaliablity(boolean productAvailable) {
		this.productAvailable = productAvailable;
	}
	public Date getReleasedate() {
		return releaseDate;
	}
	public void setReleasedate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	public int getQuantity() {
		return stockQuantity;
	}
	public void setQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public String getImageType() {
		return imageType;
	}
	public void setImageType(String imageType) {
		this.imageType = imageType;
	}
	public byte[] getImageData() {
		return imageData;
	}
	public void setImageData(byte[] imageData) {
		this.imageData = imageData;
	}
	public Product(int id, String name, String description, int price, String category, String brand, boolean productAvailable,
			Date releaseDate, int stockQuantity, String imageName, String imageType, byte[] imageData) {
		super();
		this.id = id;
		this.name = name;
		this.description= description;
		this.price = price;
		this.category = category;
		this.brand = brand;
		this.productAvailable = productAvailable;
		this.releaseDate = releaseDate;
		this.stockQuantity =stockQuantity;
		this.imageName = imageName;
		this.imageType = imageType;
		this.imageData = imageData;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", description=" + description + ", price=" + price + ", category=" + category
				+ ", brand=" + brand + ",productAvailable=" + productAvailable + ", releaseDate=" + releaseDate + ", stockQuantity="
				+ stockQuantity + ", imageName=" + imageName + ", imageType=" + imageType + ", imageData="
				+ Arrays.toString(imageData) + "]";
	}
		
    
}
